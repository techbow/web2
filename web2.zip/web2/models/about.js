'use strict';

module.exports = function AboutModel() {
    return {
        viewName: 'about'
    };
};