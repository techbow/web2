'use strict';

module.exports = function IndexModel() {
     return {
   "name": "root",
   "anotherName": "root2",
   "A":{
      "name":"Albert",
      "B":{
         "name":"Bob"
      }
   }
};
};